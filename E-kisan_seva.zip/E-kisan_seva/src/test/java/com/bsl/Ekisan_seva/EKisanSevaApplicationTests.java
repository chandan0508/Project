package com.bsl.Ekisan_seva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EKisanSevaApplicationTests {

	@Test
	void contextLoads() {
	}

}
