package com.bsl.Ekisan_seva.Service;

import com.bsl.Ekisan_seva.pojo.Admin;
import com.bsl.Ekisan_seva.pojo.User;

public interface AdminService {

	public Admin validateAdmin(String email,String password);

}
