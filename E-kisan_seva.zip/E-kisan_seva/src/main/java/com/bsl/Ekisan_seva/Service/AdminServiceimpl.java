package com.bsl.Ekisan_seva.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bsl.Ekisan_seva.daos.Admindao;
import com.bsl.Ekisan_seva.pojo.Admin;

@Service
public class AdminServiceimpl implements AdminService {

	@Autowired
	Admindao dao;

	@Override
	public Admin validateAdmin(String email, String password) {

		return dao.validateAdmin(email, password);
	}

}
