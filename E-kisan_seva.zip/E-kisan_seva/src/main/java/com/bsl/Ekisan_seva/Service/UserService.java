package com.bsl.Ekisan_seva.Service;

import com.bsl.Ekisan_seva.pojo.Admin;
import com.bsl.Ekisan_seva.pojo.User;

public interface UserService{
	
	public User validateUser(String email, String password);
	public boolean registeruser(User user);
	
}
