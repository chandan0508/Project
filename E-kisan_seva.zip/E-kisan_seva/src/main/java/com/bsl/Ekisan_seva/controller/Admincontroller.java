package com.bsl.Ekisan_seva.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bsl.Ekisan_seva.Service.AdminService;
import com.bsl.Ekisan_seva.pojo.Admin;

@RestController
@CrossOrigin(origins="*",allowedHeaders="*",methods={RequestMethod.PUT,RequestMethod.GET,RequestMethod.DELETE})
public class Admincontroller {
	@Autowired
	AdminService service;

	@GetMapping("/api/admin/{email}/{password}")
	public Admin m1(@PathVariable("email") String email, @PathVariable("password") String password) {
		return service.validateAdmin(email, password);
	}
}
