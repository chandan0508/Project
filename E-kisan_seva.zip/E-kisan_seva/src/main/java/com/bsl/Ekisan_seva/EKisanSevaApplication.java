package com.bsl.Ekisan_seva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EKisanSevaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EKisanSevaApplication.class, args);
	}

}
